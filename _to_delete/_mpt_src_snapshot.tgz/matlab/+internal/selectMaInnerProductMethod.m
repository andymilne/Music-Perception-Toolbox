function [chosen, pwCostOut, orbitCostOut] = selectMaInnerProductMethod( ...
        rVec, kVec, A, Nx, Ny, ...
        anyPer, anyRelNonper, anyRelPer, sigmaOverPMax, userMethod, ...
        verbose, relVec, nuVec, kVecY, wrapVec, truncationSigmas, ...
        pwSkipXX, pwSkipYY, orbitSkipXX, orbitSkipYY, ...
        symVec, guardForcedBulger)
%   [CHOSEN, PWCOST, ORBITCOST] = ... also returns the two predicted
%   wall times in milliseconds that the comparison rests on. They are
%   NaN on the early returns that decide without pricing (an explicit
%   userMethod, r_max <= 1, r above the shipped orbit order, and the
%   memory guard), so a caller can tell a priced decision from a
%   structural one. Exposed for calibration: fitting the cost model
%   needs the prediction beside the measurement.
%SELECTMAINNERPRODUCTMETHOD  Pick the MA inner-product method (cost model).
%   Mirror of Python dispatch._select_ma_inner_product_method. Routing
%   rules, in order: (1) userMethod override; (2) r_max <= 1 -> Bulger;
%   (3) r_max > _ORBIT_R_MAX_SHIPPED -> Bulger; (4) K-vs-r precision guard
%   (accuracy is governed by truncationSigmas, so cost decides) ->
%   Bulger; (5) predict both wall times (ms) and take the faster path
%   (ties favour Bulger). Above the rel+per sigma/P threshold the two
%   methods compute different measures rather than the same one at
%   different speeds, so the wrap axis decides which is wanted; below
%   it they agree and cost decides.
%
%   The Möbius side is priced per attribute: absolute r_a >= 2
%   attributes cost the vectorised-batch constant for their order;
%   relative attributes cost three (Nx, Ny) matrices -- the cross
%   matrix and one self matrix per density -- at the cheaper of the two
%   per-pair routes the orchestrator itself chooses between: the
%   tuple-centres closed form (MOBIUS.CLOSEDFORMATTRMATRIXFROM, at
%   M_x*M_y + M_x^2 + M_y^2 ops per pair with M = r_a!*C(K_a, r_a) read
%   from each density's own value count) or the batched
%   translation-grid contraction (MOBIUS.MAPERATTRINNERMATRIX,
%   nu_a * K_a^2 ops per matrix). The centres route is measure-blocked
%   above the sigma/P threshold (the orchestrator keeps the all-image
%   grid there), so above it the grid route is priced alone.
%
%   KVEC and KVECY are the two densities' per-attribute value counts.
%   They need not agree, and both Bulger's tuple-pair size and the
%   Möbius side's centres term are products over the two; KVECY omitted
%   means they agree. The grid term reads KVEC alone, matching
%   MOBIUS.MARELATTRPREFERSCENTRES, the gate this function predicts the
%   outcome of.
%
%   RELVEC (logical, per attribute) and NUVEC (grid node estimates,
%   per attribute) are optional; omitted, every r_a >= 2 attribute is
%   treated as relative whenever either rel flag is set (over-pricing
%   the Möbius side -> near-crossover bias toward Bulger's method,
%   the cheap-to-mispick side) with a representative node count.
%
%   Constants are provisional Python-shape values pending MATLAB
%   calibration from matlab/tests/bench_ma_dispatch.m.
    if nargin < 11; verbose = true; end
    if nargin < 12 || isempty(relVec)
        relVec = (anyRelNonper || anyRelPer) & (rVec(:).' >= 2);
    end
    if nargin < 13 || isempty(nuVec)
        nuVec = 2000 * ones(1, max(A, 1));
        nuVec = nuVec(1:A);
    end
    if nargin < 14 || isempty(kVecY)
        kVecY = kVec;
    end
    if nargin < 15
        wrapVec = {};
    end
    if nargin < 16
        truncationSigmas = [];
    end
    % A self inner product that is memoised on its density, or that the
    % requested normalisation does not consume, costs nothing at call
    % time; the per-route skip flags exclude it from that route's
    % price. The flags are per route because the two routes' memoised
    % values live under different keys (their self-IP scales differ by
    % constant prefactors that cancel only within one route's triple).
    % Defaults false reproduce the full-triple pricing exactly.
    if nargin < 17 || isempty(pwSkipXX);    pwSkipXX = false;    end
    if nargin < 18 || isempty(pwSkipYY);    pwSkipYY = false;    end
    if nargin < 19 || isempty(orbitSkipXX); orbitSkipXX = false; end
    if nargin < 20 || isempty(orbitSkipYY); orbitSkipYY = false; end
    % Per-attribute [sym] flags for the forced-Bulger feasibility guard
    % (empty -> every attribute treated as unordered, the conservative
    % count), and the guard flag itself (false for nested densities,
    % which route through the hierarchical contraction instead of the
    % flat Bulger pairwise path). Twins of the Python selector's
    % sym_vec and guard_forced_bulger.
    if nargin < 21 || isempty(symVec);            symVec = [];             end
    if nargin < 22 || isempty(guardForcedBulger); guardForcedBulger = true; end
    % NaN until the priced comparison sets them, so a caller can tell a
    % structural decision from a costed one.
    pwCostOut = NaN;
    orbitCostOut = NaN;
    if ~strcmp(userMethod, 'auto')
        chosen = userMethod;
        return;
    end
    if A > 0
        r_max = max(rVec);
    else
        r_max = 1;
    end
    if r_max <= 1
        chosen = 'bulger'; return;
    end
    if r_max > 8                        % _ORBIT_R_MAX_SHIPPED
        % No orbit table ships above r = 8, so Bulger is forced with no
        % cheaper all-image substitute: guard against an infeasible
        % tuple-pair kernel rather than let it exhaust memory. Twin of
        % the Python selector's forced-Bulger guard.
        if guardForcedBulger
            internal.guardForcedBulgerFeasible(kVec, rVec, Nx, Ny, ...
                'r above the shipped orbit order', kVecY, symVec);
        end
        chosen = 'bulger'; return;
    end
    % Accuracy is governed by truncationSigmas, not by the collection
    % size: the Mobius method's agreement with enumeration tracks the
    % truncation budget and is closest at K_a = r_a. The route is
    % therefore chosen on cost alone from here on.
    % Relative-periodic measure note. The relative periodic density is
    % defined as the transposition average of the absolute periodic
    % density, which the Möbius method computes at every sigma/P.
    % Bulger's method evaluates the kernel that wraps the pairwise
    % component differences instead: an approximation that coincides
    % with the transposition average as sigma/P -> 0 and is cheaper, so
    % the toolbox uses it in that regime. The two diverge above
    % the resolved threshold, and from around 0.06 the wrapped-difference form
    % stops being positive-definite --- its cosine similarity exceeds 1
    % for some density pairs --- so above the threshold the choice is a
    % choice of measure and the wrap axis makes it.
    % Relative-periodic wrap. Above the sigma/P threshold the two methods
    % compute different measures: Bulger's is the single-image
    % (nearest-image) reduction, the Mobius method's the all-image
    % transposition average. A density built with 'single-image' is
    % asking for the former and 'full-image' for the latter, so above the
    % threshold the wrap picks the method rather than the cost model
    % doing so. Below it the two agree numerically and either will do.
    % Callers without a wrap vector see the pre-v3 order unchanged.
    % Mirrors the Python rule in _select_ma_inner_product_method.
    if ~isempty(wrapVec) && anyRelPer && ~isempty(relVec)
        wantsSingle = false;
        wantsFull = false;
        for a = 1:min(numel(wrapVec), numel(relVec))
            if ~relVec(a), continue; end
            if strcmp(char(wrapVec{a}), 'single-image')
                wantsSingle = true;
            elseif strcmp(char(wrapVec{a}), 'full-image')
                wantsFull = true;
            end
        end
        if wantsSingle && wantsFull
            error('mpt:mixedRelPerWrap', ...
                ['Mixed rel-per wrap on a single density is not yet ' ...
                 'supported; all rel-per attributes must share a wrap ' ...
                 'value.']);
        end
        if sigmaOverPMax > ...
                internal.relPerSigmaOverPThreshold(truncationSigmas)
            if wantsSingle
                chosen = 'bulger'; return;
            elseif wantsFull
                chosen = 'mobius'; return;
            end
        end
    end

    pwSize = predictPairwiseKernelSize(rVec, kVec, A, Nx, Ny, kVecY, ...
                                       pwSkipXX, pwSkipYY);
    % Priced by the same fitted law. The per-entry form this replaces
    % assumed a fixed cost per kernel entry; measurement contradicts
    % that, the per-entry cost falling as the arrays grow, which is what
    % the fitted exponent below 1 carries.
    pwCost = relRouteCostMs('bulger', r_max, pwSize);
    centresOk = sigmaOverPMax <= ...
        internal.relPerSigmaOverPThreshold(truncationSigmas);
    orbitCost = predictOrbitCostMs(rVec, kVec, A, Nx, Ny, relVec, ...
                                   nuVec, centresOk, kVecY, ...
                                   orbitSkipXX, orbitSkipYY);
    pwCostOut = pwCost;
    orbitCostOut = orbitCost;
    if pwCost <= orbitCost
        chosen = 'bulger';
    else
        chosen = 'mobius';
    end
end


function ms = relRouteCostMs(route, r_a, term)
%RELROUTECOSTMS  Predicted wall time (ms) for one route, from its law.
%
%   Cost model for the method comparison: one power law per route and
%   tuple order,
%
%       t_ms = exp(a_r) * term ^ b_r
%
%   on the quantity each route works over -- Bulger's method and the
%   tuple-centres route on the tuple-pair entries they materialise, the
%   translation grid on the node count times the larger value count.
%   Every term carries the event-pair count, since both methods price
%   per pair. The Mobius side takes the smaller of its two routes, as
%   the orchestrator does. Each law is fitted against the quantity the
%   caller passes, not an idealisation of it, so the intercepts absorb
%   the constant factors between them; a refit must use the same terms.
%   Orders above 4 reuse the r = 4 row.
%
%   Fitted on 684 cells: r in {2, 3, 4}, value counts 5 to 40, event
%   counts 1 to 64, three kernel widths, both periodicities, three
%   weight profiles, equal and unequal value counts, each route timed in
%   isolation with relAttrRoute pinning it. Cross-validated on the
%   routing decision, eight-fold: 0.93 against 0.62 for the count-based
%   model it replaces.
%
%   Constants are per-language: the two implementations amortise
%   differently. Refit with tools/calibrateRelIpCost.m, and run it with
%   'check', true first -- three earlier fits shipped badly because an
%   axis was missing from the sweep, and the check asserts that each
%   axis varies what it claims to.
    switch route
        case 'bulger'
            A = [-7.2149, -8.0168, -7.7822];
            B = [ 0.6970,  0.7493,  0.7500];
        case 'centres'
            A = [-7.7429, -8.6263, -8.8269];
            B = [ 0.6800,  0.7781,  0.8029];
        case 'grid'
            A = [-4.1388, -2.1985, -0.5409];
            B = [ 0.3916,  0.5021,  0.5768];
        otherwise
            error('mpt:badRoute', 'Unknown route ''%s''.', route);
    end
    idx = min(max(r_a, 2), 4) - 1;
    ms = exp(A(idx)) * max(term, 1)^B(idx);
end


function sz = predictPairwiseKernelSize(rVec, kVec, A, Nx, Ny, kVecY, ...
                                        skipXX, skipYY)
    % Tuple-pair kernel entries summed over the matrices the inner
    % product will compute. Each density contributes a permutation-side
    % and a combination-side tuple count,
    %
    %   n_J = N * prod_a r_a! * C(K_a, r_a),  n_K = N * prod_a C(K_a, r_a),
    %
    % and the three matrices are the cross matrix at n_J^X * n_K^Y and
    % one self matrix per density at n_J^X * n_K^X and n_J^Y * n_K^Y.
    % Where the two densities carry the same counts the three coincide
    % and the total is three times the cross term; where they do not, the
    % larger density's self matrix dominates. For a five-value density
    % against an 80-value one at r = 2 the second self matrix holds
    % 19971200 of the 20034600 entries, so pricing the cross matrix alone
    % understates the work by 317. SKIPXX / SKIPYY exclude a self matrix
    % that is memoised or not consumed by the requested normalisation;
    % pricing it anyway would steer near-crossover routing away from
    % Bulger's method on exactly the repeated-context sweeps where
    % Bulger's marginal cost is lowest.
    if nargin < 6 || isempty(kVecY)
        kVecY = kVec;
    end
    if nargin < 7 || isempty(skipXX); skipXX = false; end
    if nargin < 8 || isempty(skipYY); skipYY = false; end
    if A == 0
        sz = Nx * Ny; return;
    end
    permX = Nx; combX = Nx;
    permY = Ny; combY = Ny;
    for a = 1:A
        ra = rVec(a); Ka = kVec(a); KaY = kVecY(a);
        if Ka < ra || KaY < ra
            sz = Inf; return;
        end
        fa = factorial(ra);
        cx = combCount(Ka, ra);
        cy = combCount(KaY, ra);
        permX = permX * fa * cx;  combX = combX * cx;
        permY = permY * fa * cy;  combY = combY * cy;
    end
    sz = permX * combY;
    if ~skipXX
        sz = sz + permX * combX;
    end
    if ~skipYY
        sz = sz + permY * combY;
    end
end


function ms = predictOrbitCostMs(rVec, kVec, A, Nx, Ny, relVec, ...
                                  nuVec, centresOk, kVecY, ...
                                  skipXX, skipYY)
    % Per-attribute sum, mirror of Python _predict_orbit_cost_ms:
    % relative attributes are priced at the cheaper of the
    % tuple-centres closed form and the batched grid contraction
    % (three matrices each), with the centres term blocked above the
    % sigma/P threshold. Constants provisional pending
    % bench_ma_dispatch calibration; measured entries cover r = 2, 3,
    % doubling per order above (over-pricing the Möbius side —
    % routing bias toward Bulger's method, the cheap-to-mispick
    % side).
    %
    % SKIPXX / SKIPYY exclude a self matrix that is memoised or not
    % consumed (mirroring predictPairwiseKernelSize). The centres term
    % drops the skipped self work exactly; the grid term and the
    % per-order absolute constants were fitted on the full
    % three-matrix computation, so they are scaled by the fraction of
    % matrices still to be computed --- an approximation that
    % under-discounts (setup is not per-matrix), biasing near-crossover
    % routing toward Bulger's method, the cheap-to-mispick side.
    % Defaults false reproduce the full-triple pricing exactly.
    ABS        = [NaN, 3.0, 11.2, 45.0, 150.0, 500.0, 1500.0, 4500.0];
    GRID_OP    = [NaN, 3.0e-5, 5.0e-5];    % r = 2, 3
    CENTRES_OP = [NaN, 4.0e-5, 9.0e-5];    % r = 2, 3
    % No flat relative base: each route's law carries its own intercept,
    % so adding one would double-count the setup it already prices.
    REL_BASE = 0.0;
    if nargin < 9 || isempty(kVecY)
        kVecY = kVec;
    end
    if nargin < 10 || isempty(skipXX); skipXX = false; end
    if nargin < 11 || isempty(skipYY); skipYY = false; end
    nMatrices = 1 + double(~skipXX) + double(~skipYY);
    ms = 0;
    if any(relVec)
        ms = REL_BASE;
    end
    pairs = Nx * Ny;
    for a = 1:A
        ra = rVec(a); Ka = kVec(a); KaY = kVecY(a);
        if relVec(a) && ra >= 2
            gridOp = GRID_OP(min(max(ra, 2), numel(GRID_OP)));
            if ra > 3    % beyond tabulated orders: double per order
                gridOp = gridOp * 2^(ra - 3);
            end
            perPair = relRouteCostMs('grid', ra, ...
                pairs * nuVec(a) * max(Ka, KaY) * (nMatrices / 3));
            if centresOk && Ka >= ra && KaY >= ra
                centresOp = CENTRES_OP(min(max(ra, 2), numel(CENTRES_OP)));
                if ra > 3
                    centresOp = centresOp * 2^(ra - 3);
                end
                mX = factorial(ra) * combCount(Ka, ra);
                mY = factorial(ra) * combCount(KaY, ra);
                centresSize = pairs * mX * mY;
                if ~skipXX
                    centresSize = centresSize + pairs * mX * mX;
                end
                if ~skipYY
                    centresSize = centresSize + pairs * mY * mY;
                end
                perPair = min(perPair, relRouteCostMs('centres', ra, ...
                    centresSize));
            end
            ms = ms + perPair;
        elseif ra >= 2
            ms = ms + ABS(ra) * (nMatrices / 3);
        end
    end
end


function c = combCount(nn, kk)
    if kk < 0 || kk > nn
        c = 0; return;
    end
    c = 1;
    for ii = 0:kk - 1
        c = c * (nn - ii) / (ii + 1);
    end
    c = round(c);
end
