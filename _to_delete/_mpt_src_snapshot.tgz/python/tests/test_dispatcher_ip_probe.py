"""Tests for inner-product method selection in cos_sim_exp_tens.

Method selection is a pure cost model
(:func:`mpt._tensor.dispatch._select_ma_inner_product_method`) choosing
between the Möbius method and Bulger's method: hard rules (correctness /
feasibility) decide first, then the cost model. What remains here are
the tests that exercise that choice through the public API and the
dispatch-message behaviour; the tests that drove the former timing
probe directly were retired with it.
"""
from __future__ import annotations

import io
import warnings
from contextlib import redirect_stdout

import numpy as np
import pytest

import mpt
from mpt import build_exp_tens, cos_sim_exp_tens
from mpt.tensor import (
    _PROBE_K_IP_TARGET,
    _PRESCREEN_IP_DOMINANCE,
)


def _dens(K: int, r: int, sigma: float = 1.0,
          is_rel: bool = False, is_per: bool = False, seed: int = 0):
    rng = np.random.default_rng(seed)
    p = np.sort(rng.uniform(0, 100, K))
    w = np.ones(K)
    return build_exp_tens(p, w, sigma, r, is_rel, is_per, 1200.0,
                          verbose=False)


# ----------------------------------------------------------------------
# Hard rules
# ----------------------------------------------------------------------
# ----------------------------------------------------------------------
# Analytical pre-screen
# ----------------------------------------------------------------------
# ----------------------------------------------------------------------
# Probe execution
# ----------------------------------------------------------------------
# ----------------------------------------------------------------------
# Semantic equivalence with the analytical-heuristic decision
# ----------------------------------------------------------------------


class TestSemanticEquivalence:
    """The probe-based dispatcher must produce the same cos_sim_exp_tens
    output as the analytical heuristic for any reasonable workload —
    the dispatcher only chooses which mathematically-equivalent path to
    use, not what to compute."""

    def test_explicit_orbit_matches_explicit_pairwise(self):
        dens_x, dens_y = _dens(20, 3, seed=0), _dens(20, 3, seed=1)
        sim_orbit = cos_sim_exp_tens(
            dens_x, dens_y, method="mobius", verbose=False,
        )
        sim_pair = cos_sim_exp_tens(
            dens_x, dens_y, method="bulger", verbose=False,
        )
        # Orbit and pairwise should agree to numerical precision.
        np.testing.assert_allclose(sim_orbit, sim_pair, atol=1e-10)

    def test_auto_matches_explicit_paths(self):
        dens_x, dens_y = _dens(20, 3, seed=0), _dens(20, 3, seed=1)
        sim_auto = cos_sim_exp_tens(dens_x, dens_y, verbose=False)
        sim_orbit = cos_sim_exp_tens(
            dens_x, dens_y, method="mobius", verbose=False,
        )
        np.testing.assert_allclose(sim_auto, sim_orbit, atol=1e-10)


# ----------------------------------------------------------------------
# Verbose dispatch message
# ----------------------------------------------------------------------


class TestVerboseDispatchMessage:
    def test_message_prints_when_probe_fires(self):
        """Probe-firing region (r=2 K=5, ratio just under dominance) →
        message printed."""
        dens_x, dens_y = _dens(5, 2, seed=0), _dens(5, 2, seed=1)
        mpt.reset_defaults()
        buf = io.StringIO()
        with redirect_stdout(buf):
            cos_sim_exp_tens(dens_x, dens_y, method="auto", verbose=True)
        out = buf.getvalue()
        # Probe should fire here, giving the dispatch message.
        assert "cos_sim_exp_tens" in out and "chose" in out

    def test_message_appears_when_hard_rule_decides(self):
        """r=1 → hard rule → no probe, but a dispatch message still
        fires. Under the current contract, the unprobed message names
        only the path (the routing reason is no longer part of the
        throttle key — see the throttling contract test below)."""
        dens_x, dens_y = _dens(8, 1, seed=0), _dens(8, 1, seed=1)
        mpt.reset_defaults()
        buf = io.StringIO()
        with redirect_stdout(buf):
            cos_sim_exp_tens(dens_x, dens_y, method="auto", verbose=True)
        out = buf.getvalue()
        assert "cos_sim_exp_tens: chose 'bulger' path." in out
        # Unprobed format: no parenthetical, no time estimate.
        assert "estimated" not in out

    def test_message_appears_for_user_override(self):
        """Explicit method → unprobed message fires; format names only
        the path (the routing reason for the user override is no
        longer part of the throttle key)."""
        dens_x, dens_y = _dens(20, 3, seed=0), _dens(20, 3, seed=1)
        mpt.reset_defaults()
        buf = io.StringIO()
        with redirect_stdout(buf):
            cos_sim_exp_tens(
                dens_x, dens_y, method="bulger", verbose=True,
            )
        out = buf.getvalue()
        assert "cos_sim_exp_tens: chose 'bulger' path." in out
        assert "estimated" not in out

    def test_message_throttled_within_a_top_level_call(self):
        """Throttling contract: dispatch messages are emitted at most
        once per (func, chosen) pair within a single top-level toolbox
        call. Two different routing reasons leading to the same chosen
        path collapse to a single announce — the visible distinction
        that matters is which path ran, not why. Repeated top-level
        calls each re-announce; nested calls within one top-level
        scope do not.

        Verified here via the batched form, where a single top-level
        ``cos_sim_exp_tens`` call internally evaluates many single-multiset-single-multiset
        pairs sharing the same dispatch decision: exactly one
        ``"chose"`` line should appear regardless of how many
        internal pairs are evaluated.
        """
        import numpy as np
        rng = np.random.default_rng(0)
        # Batched input: many rows, all routing to the same hard-rule
        # decision (r=1 → bulger).
        n_rows = 20
        K = 8
        p_mat_a = rng.uniform(0, 1200, size=(n_rows, K))
        p_mat_b = rng.uniform(0, 1200, size=(n_rows, K))
        mpt.reset_defaults()
        buf = io.StringIO()
        with redirect_stdout(buf):
            cos_sim_exp_tens(
                p_mat_a, None, p_mat_b, None,
                12, 1, False, True, 1200,
                verbose=True,
            )
        out = buf.getvalue()
        # Exactly one "chose" line, despite the many internal pair
        # evaluations that share the same routing decision.
        assert out.count("chose") == 1

    def test_message_re_announces_across_top_level_calls(self):
        """Each top-level user call resets the dispatch seen-set, so
        repeated identical top-level calls each emit a fresh dispatch
        message. (This differs from the older once-per-session
        throttle: per-call gives the user direct evidence of the
        decision on every interactive invocation.)
        """
        dens_x, dens_y = _dens(8, 1, seed=0), _dens(8, 1, seed=1)
        mpt.reset_defaults()
        buf = io.StringIO()
        with redirect_stdout(buf):
            cos_sim_exp_tens(dens_x, dens_y, method="auto", verbose=True)
            cos_sim_exp_tens(dens_x, dens_y, method="auto", verbose=True)
            cos_sim_exp_tens(dens_x, dens_y, method="auto", verbose=True)
        out = buf.getvalue()
        # Three top-level calls → three "chose" lines.
        assert out.count("chose") == 3
