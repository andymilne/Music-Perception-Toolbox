"""Regression tests for the centres-vs-grid gate on the multi-attribute
relative path (``_ma_rel_attr_prefers_centres``).

The gate compares predicted wall time on the two paths. Its calibration
notes (see the constants ``_CENTRES_NS_BASE`` etc. in
``mpt._tensor.cosine``) explain the empirical fit. The cells below pin
its decisions on the labelled truth set from that fit, including the
r=2 band where the previous raw-op-count gate over-selected centres by
one to two orders of magnitude in wall time.

Each case is one (K, r, sigma, span_or_period, is_per, expect_centres)
tuple. ``expect_centres`` is what the calibrated model predicts and
also what timing measurements agree with (in the cells verified to
within the crossover neighbourhood).
"""
import math

import numpy as np
import pytest

import mpt

from mpt._tensor._mobius_inner import (_ma_rel_attr_prefers_centres, _predicted_centres_wall_ns, _predicted_grid_wall_ns)


def _make_events(K, span, seed=0):
    """Non-periodic side: pitches uniform on [0, span). Column of Px."""
    rng = np.random.default_rng(seed)
    return np.sort(rng.uniform(0.0, span, size=K)).reshape(K, 1)


# ---------------------------------------------------------------------------
# Non-periodic cells — the r=2 band where the previous gate misfired
# ---------------------------------------------------------------------------

# The old gate said centres for every one of these; the new gate must
# say grid because the closed-form path is 10x-100x slower there.
_NONPER_R2_GRID = [
    # (K, sigma, span_per_side)
    (20, 15.0, 1800.0),
    (30, 15.0, 1800.0),
    (50, 15.0, 1800.0),
    (70, 15.0, 1800.0),
    (30, 30.0, 1800.0),
    (40, 5.0, 1800.0),
    (50, 5.0, 1800.0),
]


@pytest.mark.parametrize("K, sigma, span_per_side", _NONPER_R2_GRID)
def test_nonper_r2_prefers_grid(K, sigma, span_per_side):
    Px = _make_events(K, span_per_side, seed=1)
    Py = _make_events(K, span_per_side, seed=2)
    assert not _ma_rel_attr_prefers_centres(
        Px, Py, sigma, 2, True, False, 0.0
    ), f"K={K} sigma={sigma}: centres path is much slower than grid here"


# Non-periodic cells where centres is genuinely faster.
_NONPER_CENTRES = [
    # (K, r, sigma, span_per_side)
    (5, 2, 15.0, 1800.0),
    (8, 2, 15.0, 1800.0),
    (12, 2, 15.0, 1800.0),
    (6, 3, 15.0, 1800.0),
    (8, 3, 15.0, 1800.0),
    (5, 4, 15.0, 1800.0),
    (6, 4, 15.0, 1800.0),
]


@pytest.mark.parametrize("K, r, sigma, span_per_side", _NONPER_CENTRES)
def test_nonper_prefers_centres(K, r, sigma, span_per_side):
    Px = _make_events(K, span_per_side, seed=1)
    Py = _make_events(K, span_per_side, seed=2)
    assert _ma_rel_attr_prefers_centres(
        Px, Py, sigma, r, True, False, 0.0
    ), f"K={K} r={r} sigma={sigma}: centres path is cheaper here"


# ---------------------------------------------------------------------------
# Periodic cells
# ---------------------------------------------------------------------------

# Periodic cells where the gate must pick grid.
_PER_GRID = [
    # (K, r, sigma, period)
    (30, 2, 15.0, 3600.0),
    (50, 2, 15.0, 3600.0),
    (12, 3, 15.0, 3600.0),
    (10, 3, 5.0, 1200.0),
    (8, 4, 15.0, 3600.0),
]


@pytest.mark.parametrize("K, r, sigma, period", _PER_GRID)
def test_per_prefers_grid(K, r, sigma, period):
    Px = _make_events(K, period, seed=1)
    Py = _make_events(K, period, seed=2)
    assert not _ma_rel_attr_prefers_centres(
        Px, Py, sigma, r, True, True, period
    ), f"K={K} r={r} sigma={sigma} P={period}: grid is cheaper here"


# Periodic cells where centres is cheaper.
_PER_CENTRES = [
    # (K, r, sigma, period)
    (5, 2, 15.0, 3600.0),
    (8, 2, 15.0, 3600.0),
    (6, 3, 15.0, 3600.0),
    (8, 3, 15.0, 3600.0),
    (5, 4, 15.0, 3600.0),
    (6, 4, 15.0, 3600.0),
]


@pytest.mark.parametrize("K, r, sigma, period", _PER_CENTRES)
def test_per_prefers_centres(K, r, sigma, period):
    Px = _make_events(K, period, seed=1)
    Py = _make_events(K, period, seed=2)
    assert _ma_rel_attr_prefers_centres(
        Px, Py, sigma, r, True, True, period
    ), f"K={K} r={r} sigma={sigma} P={period}: centres is cheaper here"


# ---------------------------------------------------------------------------
# Trivial-early-exit cases (invariant under any calibration)
# ---------------------------------------------------------------------------

def test_gate_returns_false_for_absolute_attribute():
    Px = _make_events(20, 1800.0)
    Py = _make_events(20, 1800.0)
    assert _ma_rel_attr_prefers_centres(Px, Py, 15.0, 2, False, False, 0.0) is False


def test_gate_returns_false_for_r_below_two():
    Px = _make_events(20, 1800.0)
    Py = _make_events(20, 1800.0)
    assert _ma_rel_attr_prefers_centres(Px, Py, 15.0, 1, True, False, 0.0) is False


def test_gate_returns_false_when_K_below_r():
    # r=3 needs at least K=3, r=4 at least K=4.
    Px = _make_events(2, 1800.0)
    Py = _make_events(2, 1800.0)
    assert _ma_rel_attr_prefers_centres(Px, Py, 15.0, 3, True, False, 0.0) is False
    Px = _make_events(3, 1800.0)
    Py = _make_events(3, 1800.0)
    assert _ma_rel_attr_prefers_centres(Px, Py, 15.0, 4, True, False, 0.0) is False


def test_gate_returns_false_above_sigma_over_P_threshold():
    # Above σ/P = 0.03 the centres route reads the minimum image while
    # the grid route reads the all-image torus, so the gate must not
    # flip in that band regardless of cost.
    Px = _make_events(8, 100.0)
    Py = _make_events(8, 100.0)
    # sigma/period = 0.10 -> above threshold
    assert not _ma_rel_attr_prefers_centres(
        Px, Py, 10.0, 2, True, True, 100.0
    )


# ---------------------------------------------------------------------------
# Unequal value counts between the two densities
# ---------------------------------------------------------------------------

# The two densities need not carry the same number of values in an
# attribute: a chord against a scale, or a reference tuning against an
# equal division, is the ordinary case. Every cell above, and every cell
# in the fit the constants come from, gives both sides the same count,
# so these pin the case that count leaves untested.
#
# The centres route computes three matrices, and their element counts are
# M_x*M_y, M_x^2 and M_y^2 with M = r!*C(K, r). The second self matrix
# dominates whenever the second density carries more values, so an
# estimate reading the first count alone is low by (M_y/M_x)^2. The cells
# below sit in the band where that difference decides the route, and
# each expectation was checked against measurement: both routes were run
# explicitly within one process and their times compared as a ratio.
_UNEQUAL_PER = [
    # (K_x, K_y, r, sigma, period, expect_centres, measured ratio t_c/t_g)
    (5, 10, 2, 6.0, 1200.0, True,   0.6),
    (5, 20, 2, 6.0, 1200.0, False,  3.2),
    (5, 40, 2, 6.0, 1200.0, False,  29.0),
    (5, 60, 2, 6.0, 1200.0, False,  133.0),
    (5, 80, 2, 6.0, 1200.0, False,  519.0),
    (5, 8,  3, 6.0, 1200.0, True,   0.3),
    (5, 12, 3, 6.0, 1200.0, False,  4.5),
]


@pytest.mark.parametrize(
    "K_x, K_y, r, sigma, period, expect_centres, ratio", _UNEQUAL_PER)
def test_unequal_counts_periodic(K_x, K_y, r, sigma, period,
                                 expect_centres, ratio):
    Px = _make_events(K_x, period, seed=1)
    Py = _make_events(K_y, period, seed=2)
    got = bool(_ma_rel_attr_prefers_centres(
        Px, Py, sigma, r, True, True, period))
    assert got is expect_centres, (
        f"K_x={K_x} K_y={K_y} r={r}: centres/grid measured at "
        f"{ratio}x, so the faster route is "
        f"{'centres' if expect_centres else 'grid'}"
    )


def test_swapping_the_two_densities_does_not_change_the_centres_estimate():
    # The route computes the cross matrix and both self matrices, so its
    # element count is symmetric in the two value counts even though the
    # cross matrix alone is not.
    for r, is_per in ((2, True), (3, False), (4, True)):
        a = _predicted_centres_wall_ns(6, 30, r, is_per)
        b = _predicted_centres_wall_ns(30, 6, r, is_per)
        assert a == b


def test_larger_second_count_raises_the_centres_estimate():
    # Monotone in the second count at fixed first count: adding values to
    # one side cannot make the route cheaper.
    prev = None
    for K_y in (5, 10, 20, 40, 80):
        est = _predicted_centres_wall_ns(5, K_y, 2, True)
        if prev is not None:
            assert est > prev
        prev = est


def test_gate_returns_false_when_second_count_below_r():
    # An estimate built from C(K_y, r) = 0 would be zero and would
    # select centres unconditionally.
    Px = _make_events(8, 1200.0, seed=1)
    Py = _make_events(2, 1200.0, seed=2)
    assert not _ma_rel_attr_prefers_centres(
        Px, Py, 6.0, 3, True, True, 1200.0)


# ---------------------------------------------------------------------------
# Cost model sanity: predictions must be finite and positive.
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("K, r, is_per", [
    (5, 2, False), (15, 2, False), (60, 2, False),
    (6, 3, False), (12, 3, False),
    (5, 4, False), (8, 4, False),
    (5, 2, True), (15, 2, True), (60, 2, True),
    (5, 5, False), (6, 6, False),  # extrapolation regime
])
def test_predicted_walls_finite_and_positive(K, r, is_per):
    c = _predicted_centres_wall_ns(K, K, r, is_per)
    g = _predicted_grid_wall_ns(K, r, 15.0, 3600.0, is_per)
    assert np.isfinite(c) and c > 0
    assert np.isfinite(g) and g > 0


# ---------------------------------------------------------------------
# Forcing the route
# ---------------------------------------------------------------------

# rel_attr_route pins the route a relative attribute takes inside the
# Möbius method, which auto-dispatch otherwise chooses on a cost
# estimate. It exists so a benchmark can time one route rather than
# whichever the estimate happens to prefer, which changes partway
# through a sweep and makes the resulting curve a mixture of the two.
#
# It overrides the cost judgement only. Admissibility is not forceable:
# above the sigma/period threshold the tuple-centres route evaluates a
# kernel that is not positive definite, and with a value count below the
# tuple order its tuple set is empty.


@pytest.fixture(autouse=True)
def _restore_route_default():
    yield
    mpt.reset_defaults()


def test_forcing_either_route_overrides_the_cost_estimate():
    # A cell the estimate sends to grid, and one it sends to centres.
    big = _make_events(40, 1200.0, seed=1)
    small = _make_events(6, 1200.0, seed=2)
    assert not _ma_rel_attr_prefers_centres(
        big, big, 6.0, 2, True, True, 1200.0)
    assert _ma_rel_attr_prefers_centres(
        small, small, 6.0, 2, True, True, 1200.0)

    mpt.set_default(rel_attr_route="centres")
    assert _ma_rel_attr_prefers_centres(
        big, big, 6.0, 2, True, True, 1200.0)

    mpt.set_default(rel_attr_route="grid")
    assert not _ma_rel_attr_prefers_centres(
        small, small, 6.0, 2, True, True, 1200.0)


def test_forcing_grid_is_honoured_where_centres_is_inadmissible():
    # 'grid' is always admissible, so it never raises.
    P = _make_events(8, 1200.0, seed=1)
    mpt.set_default(rel_attr_route="grid")
    assert not _ma_rel_attr_prefers_centres(
        P, P, 240.0, 2, True, True, 1200.0)       # sigma/P = 0.2
    assert not _ma_rel_attr_prefers_centres(
        _make_events(2, 1200.0, seed=3), P, 6.0, 3, True, True, 1200.0)


def test_forcing_centres_above_the_threshold_raises():
    P = _make_events(8, 1200.0, seed=1)
    mpt.set_default(rel_attr_route="centres")
    with pytest.raises(ValueError, match="positive definite"):
        _ma_rel_attr_prefers_centres(P, P, 240.0, 2, True, True, 1200.0)


def test_forcing_centres_with_an_empty_tuple_set_raises():
    mpt.set_default(rel_attr_route="centres")
    with pytest.raises(ValueError, match="tuple set is empty"):
        _ma_rel_attr_prefers_centres(
            _make_events(2, 1200.0, seed=3),
            _make_events(8, 1200.0, seed=1),
            6.0, 3, True, True, 1200.0)


def test_auto_is_the_default_and_reset_restores_it():
    from mpt._defaults import get_default
    assert get_default("rel_attr_route") == "auto"
    mpt.set_default(rel_attr_route="grid")
    mpt.reset_defaults()
    assert get_default("rel_attr_route") == "auto"


@pytest.mark.parametrize("bad", ["Grid", "tau", "", 1, None])
def test_rejects_values_outside_the_three(bad):
    with pytest.raises(ValueError, match="rel_attr_route"):
        mpt.set_default(rel_attr_route=bad)


def test_forcing_a_route_does_not_change_the_value():
    # The two routes are numerically distinct but agree to well inside
    # the truncation floor below the threshold, so pinning one must not
    # move the answer.
    rng = np.random.default_rng(11)
    px = np.sort(rng.uniform(0, 1200, 5))
    py = np.sort(rng.uniform(0, 1200, 24))
    out = {}
    for route in ("centres", "grid"):
        mpt.set_default(rel_attr_route=route)
        out[route] = mpt.cos_sim_exp_tens(
            px, None, py, None, 6.0, 2, 1, 1, 1200.0,
            method="mobius", verbose=False)
    assert abs(out["centres"] - out["grid"]) < 1.5e-8
